<?php
include'getImpacts.php';
//echo "start .............";
//getImpact();
echo getImpacts("datacubetactical.xml", "action3"); 
//echo $cube;







?>
