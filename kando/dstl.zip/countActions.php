<?php

$cube = file_get_contents('datacubetactical.xml');
echo substr_count($cube, "Column");




?>
