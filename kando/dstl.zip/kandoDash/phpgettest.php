<?php

$fff = file_get_contents("http://localhost/25.php");
echo $fff;
?>
