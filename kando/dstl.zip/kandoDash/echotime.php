<?php

echo time();

?>
